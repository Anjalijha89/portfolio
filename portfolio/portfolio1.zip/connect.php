 <?php
   $name = $_POST['Your Name'];
   $email = $_POST['Your Email'];
   $message = $_POST['Message'];

$conn = new mysqli('localhost','root','','test1');
if($conn->connect_error){
  die('Connection Failed : '.$conn->connect_error);
}
else{
  $stmt = $conn->prepare("insert into login(name,email,message)");
  $stmt->bind_param("sss",$name, $email, $message);
  $stmt->execute();
  echo "login successfully...";
  $stmt->close();
  $conn->close();

}

 ?>


